package homeWork_2;

public interface IEmployee {
	public void show();
	public void changePosition(String ����å) throws MyException;
}
